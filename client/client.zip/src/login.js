import React, { useState, useContext } from 'react';
import Container  from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';  
import Form from 'react-bootstrap/Form';
import Col from 'react-bootstrap/Col';
//import Alert from 'react-bootstrap/Alert';
//import * as VAPI from './requests.js';

import axios from 'axios';
import { UserContext } from './App.js';
import { useHistory } from 'react-router-dom';

import { FehlerMsg } from './fehler.js';
import { ErrorContext } from './App.js';

import './login.css';
require ('dotenv').config();


const Login = ((props) => {

	const [Info, setInfo] = useState ({ name: '', passwort: ''});
	//const [Fehler, setFehler]  = useState ({fehler: false, text: ''});
	//const [Display, setDisplay] = useState ( true);

	const { User, setName} = useContext ( UserContext );
	const { Error, setError} = useContext ( ErrorContext );

	const history = useHistory();
	//  .env testen
	//let lazy = process.env.PORT ;
	//console.log ( lazy );

	const changeUser = ((e) => {
		const { name, value} = e.target;
		setInfo ( prevInfo => ({...prevInfo, [name]: value}));
	});
  
	const authenticate = ((e) => {

		e.preventDefault();

		if ( Info.name === '') {
			setError ({ show: true, title: "Eintrag fehlt", text: "Bitte Anmeldenamen eingeben!"});
			setInfo ({"name": '', "passwort": ''});
			return false;
		}
		if ( Info.passwort === '') {
			setError ({ show: true, title: "Eintrag fehlt", text: "Bitte Passwort eingeben!"});
			setInfo ({"name": '', "passwort": ''});
			return false;
		}
		let url = '/api/post/userauth';

 		axios
		.post ( url, { data: { name: Info.name, passwort: Info.passwort }})
		.then ( res => { 
			console.log ( " ----- .then ");
			if ( res.status === 200 ) {
				setName ( Info.name );
				history.push ("/");
				return true;
			}
		})
		
		.catch ( err => { 
			console.log (" ----  .catch ");

			if ( err.response.status === 404 ) {
				setError ({ show: true, title: "Loginfehler", text: "Authentifizierung fehlgeschlagen!"});
				setInfo ({"name": '', "passwort": ''});
				return false;	
			}
			else {
				setError ({ show: true, title: "Netzwerkfehler", text: <><p>{err.response.status}</p><p>{err.response.statusText}</p></>});
				setInfo ({"name": '', "passwort": ''});
				return false;
			}
		})
		
	});

	return (
			<Container id="login-total">
				<FehlerMsg />
				<Form onSubmit={authenticate} id="login-form">
					<Form.Group id="anmeldename">
						<Form.Label column sm={2} htmlFor="inputUsername">Anmeldename: </Form.Label>
						<Col >
              				<Form.Control className="input-login" id="inputUsername" name="name" value={Info.name} onChange={changeUser} />
						</Col>
					</Form.Group>
					<br />
					<Form.Group>
              			<Form.Label column sm={2} htmlFor="inputUserpasswort">Passwort: </Form.Label>
						<Col>
              				<Form.Control className="input-login" type="password" id="inputUserpasswort" name="passwort" value={Info.passwort} onChange={changeUser} />
						</Col>  
				    </Form.Group>
					<br />

					<br /><br />	
					<Form.Row  className="justify-content-center">
					<Button variant="secondary" type="submit">
            			Login
          			</Button>
					</Form.Row>  
				</Form>
			</Container>	
	);
});

export default Login;

//<Alert variant="danger" show={Fehler.fehler} transition={null} >
//{Fehler.text}
//</Alert>