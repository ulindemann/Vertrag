import React from 'react';
import Button from 'react-bootstrap/Button';
import { FehlerMsg, FT } from './fehler.js';


const TestPage = (() => {

	const Fehler = () => FehlerMsg ( FT.Network, "Unmöglicher Fehlertext");

	return (
		<div>
			<h1>Test</h1>
			<br />
			{FehlerMsg (FT.Network, "Unmöglicher Fehlertext")}			
		</div>
	);
});

export default TestPage;

//{FehlerMsg ("Unmöglicher Fehlertext")}
//<Button onClick={FehlerMsg('Möglicher Fehlertext')}>Fehler</Button>
