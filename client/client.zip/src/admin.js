import React from 'react';

const AdminPage = (() => {

	return (
		<>
			<h1>Administrationseite</h1>
		</>
	);
});

export default AdminPage;