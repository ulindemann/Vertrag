import React, { useState, useContext } from 'react';
import Modal  from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';  
import Form from 'react-bootstrap/Form';
import Col from 'react-bootstrap/Col';
import Alert from 'react-bootstrap/Alert';
import * as VAPI from './requests.js';

import axios from 'axios';
import { UserContext } from './App.js';
import { useHistory } from 'react-router-dom';

import { FehlerMsg, FT } from './fehler.js';
import { ErrorContext } from './App.js';

//import './login.css';
require ('dotenv').config();


const Login = ((props) => {

	const [Info, setInfo] = useState ({ name: '', passwort: ''});
	const [Fehler, setFehler]  = useState ({fehler: false, text: ''});
	const [Display, setDisplay] = useState ( true);

	const { LoggedIn, User, setName} = useContext ( UserContext );
	const { Error, setError} = useContext ( ErrorContext );

	const history = useHistory();
	//  .env testen
	//let lazy = process.env.PORT ;
	//console.log ( lazy );

	const changeUser = ((e) => {
		const { name, value} = e.target;
		setInfo ( prevInfo => ({...prevInfo, [name]: value}));
	});
  
	const authenticate = ((e) => {
		//console.log ( User.name + " " + User.passwort );

		e.preventDefault();
		setFehler ({ "fehler": false, "text": "" });

		if ( Info.name === '') {
			setFehler ({ "fehler": true, "text": "Bitte Login eingeben!"});
			setInfo ({"name": '', "passwort": ''});
			return false;
		}
		if ( Info.passwort === '') {
			setFehler ({ "fehler": true, "text": "Bitte Passwort eingeben!"});
			setInfo ({"name": '', "passwort": ''});
			return false;
		}
		let url = '/api/post/userauth';

 		axios
		.post ( url, { data: { name: Info.name, passwort: Info.passwort }})
		.then ( res => { 
			console.log ( res);
			if ( res.status === 200 ) {
				//props.func ( { "logged": true, "name": User.name} );
				UserContext.setName ( Info.name );
				setDisplay ( false );
				history.push ("/");
				return true;
			}
		})
		.catch ( err => { 
			if ( err ) {
			console.log (err.response);

			if ( err.response.status === 404 ) {
				setFehler ({ "fehler": true, "text": "Authentifizierung fehlgeschlagen!"});
				return false;	
			}
			else {
				setFehler ({ "fehler": true, "text": <><p>{err.response.status}</p><p>{err.response.statusText}</p></> });
				return false;
			}
			}
		})
	});

	const Hide = (() => {
		UserContext.setName ( Info.name );
		history.push ("/");
	});

	return (
		<Modal show={Display} animation={false} onHide={Hide}>
			<Modal.Header style={{ backgroundColor: "#0000aa", color: "#ffffff"}}>
          		<Modal.Title>Login</Modal.Title>
        	</Modal.Header>
			<br />
        	<Modal.Body>
				<Form>
					<Form.Row>
						<Form.Label column="lg" htmlFor="inputUsername">Anmeldename: </Form.Label>
						<Col sm={8} >
              				<Form.Control className="input-login" id="inputUsername" name="name" value={User.name} onChange={changeUser} />
						</Col>
					</Form.Row>
					<br />
					<Form.Row>
              			<Form.Label column="lg" htmlFor="inputUserpasswort">Passwort: </Form.Label>
						<Col sm={8} >
              				<Form.Control className="input-login" type="password" id="inputUserpasswort" name="passwort" value={User.passwort} onChange={changeUser} />
						</Col>  
				    </Form.Row>
					<br />
					<Alert variant="danger" show={Fehler.fehler} transition={null} >
						{Fehler.text}
					</Alert>
					<br /><br />	
					<Form.Row  className="justify-content-center">
					<Button variant="secondary" onClick={authenticate}>
            			Login
          			</Button>
					</Form.Row>  
				</Form>

			</Modal.Body>
		</Modal>
	);
});

export default Login;