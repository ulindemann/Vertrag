import React, { useState, useEffect } from 'react';

import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

import * as moment from 'moment';
import 'moment/locale/de';

import { sprintf } from 'sprintf-js';

//---------------------------------------------------------------------------------------------------------
import Socket from './socket.js';
import TestChat from './chat.js';
//---------------------------------------------------------------------------------------------------------


import * as VAPI from './requests.js';
import { KundenTypeAhead, VertragsartTypeAhead, NummerTypeAhead } from './customtypeahead.js';
import { Navi } from "./nav.js";
import Login from './login.js';

import 'bootstrap/dist/css/bootstrap.min.css';
import './Typeahead.css';
import './App.css';


const Standorte = [
{ id: 1, name: 'BRAU' },
{ id: 2, name: 'BRB' },
{ id: 3, name: 'BUERK' },
{ id: 4, name: 'ERGO' },
{ id: 5, name: 'ERK' },
{ id: 6, name: 'GAE_14' },
{ id: 7, name: 'GAE_57' },
{ id: 8, name: 'HAG' },
{ id: 9, name: 'HZD' },
{ id: 10, name: 'KD' },
{ id: 11, name: 'KWB' },
{ id: 12, name: 'KWS_TW' },
{ id: 13, name: 'MARZ' },
{ id: 14, name: 'PLAU' },
{ id: 15, name: 'POT' },
{ id: 16, name: 'STW' },
{ id: 17, name: 'Teltow_Lanky' },
{ id: 18, name: 'WEX' },
{ id: 19, name: 'WI' },
{ id: 20, name: 'WVS' }
];

//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------

const App = (() => {

  const [Vertrag, setVertrag] = useState ({
    Id: -1,
    Aktiv: true,
    VertragsNummer: '',
    IdKunde: -1,
    KName: '',
    IdArt: 1,
    Art: '',
    IdStandort: 10,
    Standort: 'KD',
    VStart: "2020-08-01", //moment().format('YYYY-MM-DD'), // Vertragsstart
    VLaufzeit: 12,         // Laufzeit
    VNext: "2021-08-01",  // Naechste Verl., Vstart + VLaufzeit
    KueFrist: 3,          // Monate 
    KueNext: '2021-05-01',          // VNext - KueFrist
    Vorlauf: 30,           // Tage
    KueEff: '2021-04-01',           // KueNext - Vorlauf
    ZahlungMon: 0.00,
    ZahlungpviertelA: 0.00,
    ZahlungphalbA: 0.00,
    ZahlungpA: 0.00,
    KostenpA: 0.00,
    KNummer: '',
    KStrasse: '',
    KPlzOrt: '',
    KTel: '',
    KFax: '',
    KMail: '',  
    Sonstiges: '',
    LastMod: '',
    File: '',
    Pfad: ''
  });

  // SearchArry fuer Kundendropdown
  const [Kunden, setKunden] = useState ({isLoading: false, options: []});

  // Vertragsartdropdown
  const [VArt, setVArt] = useState ({isLoading: false, options: []});

  // Vertragsnummerdropdown
  const [VNummer, setVNummer]  = useState ({isLoading: false, options: []});

  // Initialisieren
  //  Vertrags --- Fristen
  
  /*
  useEffect (() => {
    
    let start = moment().format ("YYYY-MM-DD");
    let dauer = 12;
    let ende  = moment(start).add ( dauer, 'months').format('YYYY-MM-DD');

    let kfrist = 3;
    let next   = moment(ende).subtract( kfrist, 'months').format('YYYY-MM-DD');
    let vorlauf = 30;

    let keff = moment(next).subtract( vorlauf, 'days').format('YYYY-MM-DD');

    console.log ( "Initialisiere: ");
    console.log 
    ("VStart: " + start + ", VLaufzeit: " + dauer + ", VNext: " +  ende + ", Kuefrist: " + kfrist + ", KueNext: " + next + ", Vorlauf: " + vorlauf + ", KueEff: "  + keff);    


    setVertrag (prevVertrag => ({...prevVertrag, "VStart": start, "VLaufzeit": dauer, "VNext": ende, "KueFrist": kfrist, "KueNext": next,
                                                  "Vorlauf": vorlauf, "KueEff": keff }));

    console.log 
    ("VStart: " + Vertrag.VStart + ", VLaufzeit: " + Vertrag.VLaufzeit + ", VNext: " +  Vertrag.VNext + ", Kuefrist: " + Vertrag.KueFrist + ", KueNext: " + Vertrag.KueNext + ", Vorlauf: " + Vertrag.Vorlauf + ", KueEff: "  + Vertrag.KueEff);    
                                              
  }, []);
  */
  
  //  Vertragskosten
  useEffect (() => {
    let mon = 0.00, viertel = 0.00, halb = 0.00, jahr = 0.00, total = 0.00;
    setVertrag (prevVertrag => ({...prevVertrag, "ZahlungMon": mon, "ZahlungpviertelA": viertel, "ZahlungphalbA": halb, "ZahlungpA": jahr, "KostenpA": total }));
  }, []);
  
  //----- aktiv Toggle
  const toggleAktiv = ((e) => {

    const { name, checked} = e.target;
    setVertrag ( prevVertrag => ({...prevVertrag, [name]: checked}));
  });

  //
  //  setVertragStandart --- alles ohne Sonderfälle
  //
  const setVertragStandart = ((e) => {
      const { name, value} = e.target;
      setVertrag ( prevVertrag => ({...prevVertrag, [name]: value}));
  });

  const setVertragStandort = ((e) => {

    const value = e.target.value;
    const elem = Standorte.find (item => item.name === value);

    setVertrag ( prevVertrag => ({...prevVertrag, "Standort": value, "IdStandort": elem.id}));
  });

  //---------  Vertragszeiten

  const setVertragszeiten = ((e) => {
  
    const { name, value } = e.target;

    let start = Vertrag.VStart; 
    let    dauer = Vertrag.VLaufzeit;
    let    kfrist = Vertrag.KueFrist;
    let    vorlauf = Vertrag.Vorlauf;
    

    console.log ("VStart: " + start + ", VLaufzeit: " + dauer + ", Kuefrist: " + kfrist + ", Vorlauf: " + vorlauf );    

    switch ( name ) {
      case "VStart":
        start = moment(value).format('YYYY-MM-DD');
        break;
      case "VLaufzeit":
        dauer = value;
        break;  
      case "KueFrist":
        kfrist = value;
        break;
      case "Vorlauf":
        vorlauf = value;
        break;  
      default:
        alert ("Fehler: Ungültiges Feld --> " + name );
        break;    
      }
    //let ende  = moment(start).add ( dauer, 'months').format('YYYY-MM-DD');
    //let next   = moment(ende).subtract( kfrist, 'months').format('YYYY-MM-DD');
    //let keff = moment(next).subtract( vorlauf, 'days').format('YYYY-MM-DD');

    let ende  = moment(start).add ( dauer, 'months').format('YYYY-MM-DD');
    let next   = moment(ende).subtract( kfrist, 'months').format('YYYY-MM-DD');
    let keff = moment(next).subtract( vorlauf, 'days').format('YYYY-MM-DD');

    //console.log 
    //("VStart: " + start + ", VLaufzeit: " + dauer + ", VNext: " +  ende + ", Kuefrist: " + kfrist + ", KueNext: " + next + ", Vorlauf: " + vorlauf + ", KueEff: "  + keff);    


    setVertrag (prevVertrag => ({...prevVertrag, "VStart": start, "VLaufzeit": dauer, "VNext": ende, "KueFrist": kfrist, "KueNext": next,
                                                  "Vorlauf": vorlauf, "KueEff": keff }));

  });

  //-- Zahlungupdate ---------------------------------

  const setZahlung = ((e) => {

    const { name, value } = e.target;
    let mon = 0.00, viertel = 0.00, halb = 0.00, jahr = 0.00, total = 0.00;
 
    switch ( name ) {
      case "ZahlungMon": 
        mon = value;
        total = value * 12.0;
        break;
      case "ZahlungpviertelA":
        viertel = value;
        total = value * 4.0;
        break;
      case "ZahlungphalbA": 
        	halb = value;
          total = value * 2.0;
          break;
      case "ZahlungpA": 
          jahr = value * 1.0;
          total = value * 1.0;
          break;
      default:
        alert ("Fehler: Ungültiges Feld --> " + name );
        break;    
    }
    let total_out = sprintf ("%.2f €", total  );
    setVertrag (prevVertrag => ({...prevVertrag, "ZahlungMon": mon, "ZahlungpviertelA": viertel, "ZahlungphalbA": halb, "ZahlungpA": jahr, "KostenpA": total_out }));
  });

  // rein in die Datenbank
  const sendData = ((e) => {

    e.preventDefault();
    console.log ( Vertrag );

    VAPI.appendVertrag ( Vertrag );
    //var response = VAPI.getTest();
    //console.log ( "sendData " + response.data );
  });

  //const debugData = ((e) => {
  //  console.log ( Vertrag );
  //});

  // <Socket /> ist raus !!!!!
  //<Form.Label htmlFor="inputVPartner">Vertrag mit: </Form.Label>
  //<Form.Control type="text" className="mx-sm-3" id="inputVPartner" name="KName" value={Vertrag.KName} onChange={setVPartner} />

  const [User, setUser] = useState ({logged: false, name: ''}); 
  
  return (
    <div className="App">
      if ( User.logged === false ) {
      <Login user={User} func={setUser} />
      }
    
      <Navi user={User.name} /> 
      <Row>
        <Col md="auto">
        <Form className="Form-Total" onSubmit={sendData} >
        <div className="input-vertrag">
          <Row><h5>Vertrag</h5></Row>
          <br />
          <Row>
              <Form.Check type="checkbox" label="Aktiv" onChange={toggleAktiv} name="Aktiv" checked={Vertrag.Aktiv} />
          </Row> 
          <Row> 
              <label htmlFor="inputVertragsnummer">Vertragsnummer: </label>
              <NummerTypeAhead  id="inputVertragsnummer" className="input-vdata rounded-0" vertrag={Vertrag} vertragf={setVertrag} nummer={VNummer} nummerf={setVNummer} />

              <span>
              <Form.Label htmlFor="inputAktualisiert">Zuletzt aktualisiert: </Form.Label>
              <Form.Control type="text"  className="input-vdata rounded-0" id="inputAktualisiert" name="LastMod" value={Vertrag.LastMod} disabled />
              </span>
          </Row>
          <br />
          <Row>
              <label htmlFor="inputVertragspartner">Vertrag mit ..: </label>    
              <KundenTypeAhead  id="inputVertragspartner" className="input-vdata rounded-0" vertrag={Vertrag} vertragf={setVertrag} kunden={Kunden} kundenf={setKunden} />
          </Row>
          <Row>          
              <label htmlFor="inputVertragsart">Vertragsart ..: </label>   
              <VertragsartTypeAhead id="inputVertragsart" className="input-vdata rounded-0" vertrag={Vertrag} vertragf={setVertrag} vart={VArt} vartf={setVArt} />
            </Row>          
            <Row>  
              <div className="form-group">
                <label htmlFor="inputStandort">Standort: </label>
                <select className="form-control input-vdata rounded-0" id="inputStandort" value={Vertrag.Standort} name="Standort" onChange={setVertragStandort} >
                <option>{Standorte[0].name}</option> 
                <option>{Standorte[1].name}</option>
                <option>{Standorte[2].name}</option>
                <option>{Standorte[3].name}</option>
                <option>{Standorte[4].name}</option>
                <option>{Standorte[5].name}</option>
                <option>{Standorte[6].name}</option>
                <option>{Standorte[7].name}</option>
                <option>{Standorte[8].name}</option>
                <option>{Standorte[9].name}</option>
                <option>{Standorte[10].name}</option>
                <option>{Standorte[11].name}</option>
                <option>{Standorte[12].name}</option>
                <option>{Standorte[13].name}</option>
                <option>{Standorte[14].name}</option>
                <option>{Standorte[15].name}</option>
                <option>{Standorte[16].name}</option>
                <option>{Standorte[17].name}</option>
                <option>{Standorte[18].name}</option>
                <option>{Standorte[19].name}</option>
                </select>
              </div>
          </Row>
          </div>
          <div className="input-laufzeit">
          <Row><h5>Laufzeit</h5></Row>
          <br />
          <Row>
              <Form.Label htmlFor="inputVStart">Vertragsstart .........: </Form.Label>
              <Form.Control type="date" className="input-dates rounded-0" id="inputVStart" name="VStart" value={Vertrag.VStart} onChange={setVertragszeiten} />

              <Form.Label htmlFor="inputNextV">Nächste Verlängerung : </Form.Label>
              <Form.Control type="date" className="input-dates rounded-0" id="inputNextV" name="VNext" value={Vertrag.VNext} disabled />
          </Row>
          <Row>
              <Form.Label htmlFor="inputLaufzeit">Laufzeit .... [Monate]): </Form.Label>
              <Form.Control type="number" className="input-dates rounded-0" id="inputLaufzeit" name="VLaufzeit" value={Vertrag.VLaufzeit} onChange={setVertragszeiten} />
          </Row>
          <Row>    
              <Form.Label htmlFor="inputKFrist">Kündigungsfrist[Monate]: </Form.Label>
              <Form.Control type="number" className="input-dates rounded-0" id="inputKFrist" name="KueFrist" value={Vertrag.KueFrist} onChange={setVertragszeiten} />
              <Form.Label htmlFor="inputKNext">Nächste Kündigung ...: </Form.Label>
              <Form.Control type="date" className="input-dates rounded-0" id="inputKNext" name="KueNext" value={Vertrag.KueNext} disabled/>
          </Row>
          <Row>   
              <Form.Label htmlFor="inputVorlauf">Vorlauf ........ [Tage]: </Form.Label>
              <Form.Control type="number" className="input-dates rounded-0" id="inputVorlauf" name="Vorlauf" value={Vertrag.Vorlauf} onChange={setVertragszeiten} />
              <Form.Label htmlFor="inputKmVorlauf">Kündigung mit Vorlauf: </Form.Label>
              <Form.Control type="date" className="input-dates rounded-0" id="inputKmVorlauf" name="KueEff" value={Vertrag.KueEff} disabled/>
          </Row>
          </div>
          <div className="input-zahlung"> 
          <Row><h5>Zahlung</h5></Row>
          <br />
          <Row>
              <Form.Label htmlFor="inputZahlungMo">Monatliche Zahlung .....: </Form.Label>
              <Form.Control className="input-euro rounded-0" type="number" min="0.00" step="0.01" id="inputZahlungMo" name="ZahlungMon" value={Vertrag.ZahlungMon} onChange={setZahlung} />

              <Form.Label htmlFor="inputKostenpA">Kosten pro Jahr: </Form.Label>
              <Form.Control className="input-euro rounded-0" type="text" id="inputKostenpA" name="KostenpA" value={Vertrag.KostenpA} disabled />

          </Row>
          <Row>  
              <Form.Label htmlFor="inputZahlung">Vierteljährliche Zahlung: </Form.Label>
              <Form.Control className="input-euro rounded-0" type="number" min="0.00" step="0.01" id="inputZahlung" name="ZahlungpviertelA" value={Vertrag.ZahlungpviertelA} onChange={setZahlung} />
          </Row>  
          <Row>  
              <Form.Label htmlFor="inputhJZahlung">Halbjährliche Zahlung ..: </Form.Label>
              <Form.Control className="input-euro rounded-0" type="number" min="0.00" step="0.01" id="inputhJZahlung" name="ZahlungphalbA" value={Vertrag.ZahlungphalbA} onChange={setZahlung} />
          </Row>  
          <Row>  
              <Form.Label htmlFor="inputJZahlung">Jährliche Zahlung ......: </Form.Label>
              <Form.Control className="input-euro rounded-0" type="number" min="0.00" step="0.01" pattern="\d+(,\d{2})" placeholer="0.00" id="inputJZahlung" name="ZahlungpA" value={Vertrag.ZahlungpA} onChange={setZahlung} />
          </Row>  
          </div>
          <div className="input-kunde">
          <Row><h5>Vertragspartner</h5></Row>
          <br />
          <Row>
              <Form.Label htmlFor="inputKundenNr">Kundennummer: </Form.Label>
              <Form.Control type="text" className="input-kdata rounded-0" id="inputKundenNr" name="KNummer" value={Vertrag.KNummer} onChange={setVertragStandart} />
          </Row>
          <Row>  
              <Form.Label htmlFor="inputKundenName">Name .......: </Form.Label>
              <Form.Control type="text" className="input-kdata rounded-0" id="inputKundenName" name="KName" value={Vertrag.KName} onChange={setVertragStandart} />
          </Row>
          <Row>  
              <Form.Label htmlFor="inputKundenStr">Straße .....: </Form.Label>
              <Form.Control type="text" className="input-kdata rounded-0" id="inputKundenStr" name="KStrasse" value={Vertrag.KStrasse} onChange={setVertragStandart} />
          </Row>
          <Row>  
              <Form.Label htmlFor="inputKundenOrt">PLZ + Ort ..: </Form.Label>
              <Form.Control type="text" className="input-kdata rounded-0" id="inputKundenOrt" name="KPlzOrt" value={Vertrag.KPlzOrt} onChange={setVertragStandart} />
          </Row>
          <Row>  
              <Form.Label htmlFor="inputKundenTelefon">Telefon ....: </Form.Label>
              <Form.Control type="text" className="input-kdata rounded-0" id="inputKundenTelefon" name="KTel" value={Vertrag.KTel} onChange={setVertragStandart} />
          </Row>
          <Row>
              <Form.Label htmlFor="inputKundenFax">Fax ........: </Form.Label>
              <Form.Control type="text" className="input-kdata rounded-0" id="inputKundenFax" name="KFax" value={Vertrag.KFax} onChange={setVertragStandart} />
          </Row>  
          <Row>  
              <Form.Label htmlFor="inputKundenEmail">Mail .......: </Form.Label>
              <Form.Control type="email" className="input-kdata rounded-0" id="inputKundenEmail" name="KMail" value={Vertrag.KMail} onChange={setVertragStandart} />
          </Row>
          </div>
          <div className="input-sonstiges">
          <Row><h5>Sonstiges</h5></Row>
          <br />
          <Row>
              <Form.Label htmlFor="inputSonstiges">Bemerkung:   </Form.Label>
              <Form.Control as="textarea" rows="4" className="input-bemerkung" id="inputSonstiges" name="Sonstiges" value={Vertrag.Sonstiges} onChange={setVertragStandart} />
          </Row>
          <br />
          <Row>    
              <Form.Label htmlFor="inputDatei">Datei ...: </Form.Label>
              <Form.Control type="text" className="input-bemerkung" id="inputDatei" name="File" value={Vertrag.File} onChange={setVertragStandart} />
          </Row>
          <Row>    
              <Form.Label htmlFor="inputDateiPfad">Pfad ...: </Form.Label>
              <Form.Control type="text" className="input-bemerkung" id="inputDateiPfad" name="Pfad" value={Vertrag.Pfad} onChange={setVertragStandart} />
          </Row>
          </div>
          <div className="input-buttons">
            <Button variant="secondary" size="lg" type="submit">Speichern</Button>
          </div>
        </Form>
        </Col>
        <Col>
          <TestChat user={User.name} />
        </Col>
      </Row>
    </div>
  );
});
//<Button variant="primary" onClick={debugData} >Testen</Button>


export default App;

//<Form.Control type="text" className="mx-sm-3" id="inputTest" name="iTest" value={TestVal} />

//<Col>
//<div className="form-group">
//  <label htmlFor="inputVArt">Vertragsart: </label>
//  <select className="form-control" id="inputVArt" value={Vertrag.Art} name="Art" onChange={setVertragsArt} >
//  <option>{VArten[0].name}</option> 
//  <option>{VArten[1].name}</option>
//  <option>{VArten[2].name}</option>
//  <option>{VArten[3].name}</option>
//  </select>
//</div>
//</Col>

//<header className="App-header">
//<img
//          src="lwerk-logo.png"
//          className="d-inline-block align-top"
          //className ="align-center"
//          width="200"
//          height="60"
//          alt="lwerk"
//      />
//</header>